package hw08;

public class DuplicateItemException extends RuntimeException {
	public DuplicateItemException(String message) {
		super(message);
	}
}
